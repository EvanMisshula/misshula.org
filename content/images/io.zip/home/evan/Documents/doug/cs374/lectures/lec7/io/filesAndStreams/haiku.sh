 cat haiku.txt | ./capslocker
