cat lines | ./shortlononly
