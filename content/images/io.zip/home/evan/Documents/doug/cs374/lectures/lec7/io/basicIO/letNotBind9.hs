
main = do
    let a = "hell"
        b = "yeah"
    putStrLn $ a ++ " " ++ b
