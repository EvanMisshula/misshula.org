
main = do   putChar 't'
            putChar 'e'
            putChar 'h'
