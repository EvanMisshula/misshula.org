main = do   print True
            print 2
            print "haha"
            print 3.2
            print [3,4,3]
