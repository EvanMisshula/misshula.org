cat words.txt | runhaskell palindromes.hs
