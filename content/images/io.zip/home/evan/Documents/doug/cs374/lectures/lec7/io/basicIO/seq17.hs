main = do
    rs <- sequence [getLine, getLine, getLine]
    print rs
