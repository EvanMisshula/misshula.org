
main = do   putStr "Hey, "
            putStr "I'm "
            putStrLn "Andy!" 
