main = do
    a <- getLine
    b <- getLine
    c <- getLine
    print [a,b,c]
