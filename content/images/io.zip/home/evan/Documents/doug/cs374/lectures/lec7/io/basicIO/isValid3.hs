nameTag = "Hello, my name is " ++ getLine
